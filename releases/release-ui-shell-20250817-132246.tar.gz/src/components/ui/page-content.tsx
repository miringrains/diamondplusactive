"use client"

import * as React from "react"
import { cn } from "@/lib/utils"
import { Container } from "@/components/layout/Container"

interface PageContentProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
  // For video pages with dual sidebars
  hasCourseSidebar?: boolean
  // For pages that need full width (like video grid layouts)
  fullWidth?: boolean
}

export function PageContent({ 
  children, 
  className, 
  hasCourseSidebar = false,
  fullWidth = false,
  ...props 
}: PageContentProps) {
  // For pages that need full width or have special layout needs
  if (fullWidth || hasCourseSidebar) {
    return (
      <div 
        className={cn(
          "min-h-screen w-full",
          "px-4 py-6 md:px-6 md:py-8 lg:px-8 lg:py-10",
          className
        )}
        {...props}
      >
        {children}
      </div>
    )
  }

  // Default: Use Container for consistent width management
  return (
    <Container 
      className={cn(
        "min-h-screen",
        "py-6 md:py-8 lg:py-10",
        className
      )}
      {...props}
    >
      {children}
    </Container>
  )
}

// Companion component for page headers with consistent styling
export function PageHeader({ 
  children, 
  className,
  ...props 
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div 
      className={cn(
        "mb-6 md:mb-8",
        className
      )} 
      {...props}
    >
      {children}
    </div>
  )
}

// Component for page sections with consistent spacing
export function PageSection({ 
  children, 
  className,
  ...props 
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div 
      className={cn(
        "mb-8 md:mb-10",
        className
      )} 
      {...props}
    >
      {children}
    </div>
  )
}
