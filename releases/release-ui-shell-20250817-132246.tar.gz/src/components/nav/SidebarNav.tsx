"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Video, Shield, LogOut, User, Users, Settings, LayoutDashboard } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"

export interface NavItem {
  title: string
  href: string
  icon: React.ComponentType<{ className?: string }>
  tooltip?: string
  adminOnly?: boolean
}

// Static navigation configuration
const NAV_ITEMS: NavItem[] = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: Home,
    tooltip: "Dashboard",
  },
  {
    title: "Courses",
    href: "/courses",
    icon: Video,
    tooltip: "Courses",
  },
  {
    title: "Admin Dashboard",
    href: "/admin",
    icon: LayoutDashboard,
    tooltip: "Admin Dashboard",
    adminOnly: true,
  },
  {
    title: "Manage Courses",
    href: "/admin/courses",
    icon: Video,
    tooltip: "Manage Courses",
    adminOnly: true,
  },
  {
    title: "Users",
    href: "/admin/users",
    icon: Users,
    tooltip: "Manage Users",
    adminOnly: true,
  },
  {
    title: "Settings",
    href: "/admin/settings",
    icon: Settings,
    tooltip: "System Settings",
    adminOnly: true,
  },
]

interface SidebarNavProps {
  isAdmin?: boolean
  className?: string
}

/**
 * Reusable sidebar navigation component with active state management.
 * Filters menu items based on user role.
 */
export function SidebarNav({ isAdmin = false, className }: SidebarNavProps) {
  const pathname = usePathname()

  // Filter items based on admin status
  const visibleItems = NAV_ITEMS.filter(item => !item.adminOnly || isAdmin)

  // Check if a path is active
  const isActive = (href: string) => {
    if (href === "/dashboard" || href === "/admin") {
      return pathname === href
    }
    return pathname.startsWith(href)
  }

  return (
    <SidebarMenu className={className}>
      {visibleItems.map((item) => (
        <SidebarMenuItem key={item.href}>
          <SidebarMenuButton 
            asChild 
            tooltip={item.tooltip}
            className={cn(
              isActive(item.href) && "bg-accent text-accent-foreground"
            )}
          >
            <Link href={item.href}>
              <item.icon className="h-4 w-4" />
              <span>{item.title}</span>
            </Link>
          </SidebarMenuButton>
        </SidebarMenuItem>
      ))}
    </SidebarMenu>
  )
}
